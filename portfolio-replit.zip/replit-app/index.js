const express = require('express');
const fetch = require('node-fetch');
const path = require('path');
const app = express();

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// This keeps your API key safe on the server
const API_KEY = process.env.ANTHROPIC_API_KEY;

app.post('/ask', async (req, res) => {
  if (!API_KEY) {
    return res.json({ error: 'Set ANTHROPIC_API_KEY in Replit Secrets (🔒 icon in sidebar)' });
  }
  const { prompt, useSearch } = req.body;
  const body = {
    model: 'claude-sonnet-4-20250514',
    max_tokens: 1500,
    messages: [{ role: 'user', content: prompt }]
  };
  if (useSearch) body.tools = [{ type: 'web_search_20250305', name: 'web_search' }];

  try {
    const r = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': API_KEY,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify(body)
    });
    const data = await r.json();
    if (data.error) return res.json({ error: data.error.message });
    const text = data.content.filter(c => c.type === 'text').map(c => c.text).join('');
    res.json({ text });
  } catch (e) {
    res.json({ error: e.message });
  }
});

app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, '0.0.0.0', () => console.log(`Running on port ${PORT}`));
